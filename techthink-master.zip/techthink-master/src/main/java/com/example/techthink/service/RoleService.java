package com.example.techthink.service;

import com.example.techthink.persistence.Role;

public interface RoleService {

    Role getRoleById(Long id);
}
