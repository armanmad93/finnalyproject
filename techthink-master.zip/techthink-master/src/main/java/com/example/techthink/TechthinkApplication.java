package com.example.techthink;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TechthinkApplication {

    public static void main(String[] args) {
        SpringApplication.run(TechthinkApplication.class, args);
    }

}
