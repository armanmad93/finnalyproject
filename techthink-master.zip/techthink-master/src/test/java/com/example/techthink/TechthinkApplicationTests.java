package com.example.techthink;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TechthinkApplicationTests {

    @Test
    void contextLoads() {
    }

}
