package com.example.techthink.persistence;

public enum  RoleName {
    USER, //student
    PROFESSOR,
    ADMIN,
    STUDENT
}