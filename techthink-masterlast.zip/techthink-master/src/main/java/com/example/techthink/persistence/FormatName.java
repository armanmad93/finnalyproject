package com.example.techthink.persistence;

public enum FormatName {
    OFFLINE,
    ONLINE,
    HYBRID
}
